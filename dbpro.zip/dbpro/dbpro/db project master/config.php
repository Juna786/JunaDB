<?php

$appname = 'dbpro';

$dbhost = '54.158.85.242';
$dbname = 'test';
$dbuser = 'root';
$dbpass = 'root';

$host       = "http://ec2-54-158-85-242.compute-1.amazonaws.com";
$username   = "newguyz";
$password   = "newguy01";
$dbname     = "test";
$dsn        = "mysql:host=$host;dbname=$dbname";
$options    = array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
              );