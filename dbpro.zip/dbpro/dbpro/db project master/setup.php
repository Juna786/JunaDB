<!DOCTYPE html>
<html>
    <head>
        <title>Setting up database</title>
    </head>
    <body>

        <h3>Setting up...</h3>

<?php
    require_once __DIR__.'/config.php';
    require_once __DIR__.'/init.php';


?>

        <br>...done.
    </body>
</html>
